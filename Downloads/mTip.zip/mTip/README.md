# mTip
A flexible, simple and extensible Javascript plugin for custom tooltips by Manish Kumar under MIT license.
###Compatible with 
####Mozilla Firefox
####Google Chrome, 
####IE8+ 
####Others.

No Jquery required.
Fully Customizable with available options

###More Features Coming Soon.
